from sqlalchemy.orm import declarative_base
from sqlalchemy import create_engine

from data.config import db_url

Base = declarative_base()


from .users import Users
from .events import Events
from .user_events import UserEvent
from .admins import Admin
from .team import Team
from .news import News
