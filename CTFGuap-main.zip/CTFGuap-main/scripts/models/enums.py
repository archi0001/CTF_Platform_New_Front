import enum
from symtable import Class


class EventStatus(str, enum.Enum):
    OPEN = "open"
    CLOSED = "closed"
    PRIVATE = "private"


class UserStatus(str, enum.Enum):
    ACTIVE = 'active'
    PENDING = 'pending'
    BANNED = 'banned'


class AdminRoles(str, enum.Enum):
    ELDER = 'elder'
    EDITOR = 'editor'
    JUNIOR = 'junior'


class NewsStatus(str, enum.Enum):
    DRAFT = 'draft'
    PUBLISHED = 'published'
    SCHEDULED = 'scheduled'
