db_url = "postgresql+psycopg://myuser:mypassword@localhost/mydb"
