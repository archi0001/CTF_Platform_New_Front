from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import or_

from scripts.models import *
from sqlalchemy.orm import Session
# from scripts.db import create_session
# from scripts.db import engine

import hashlib

app = FastAPI()
templates = Jinja2Templates(directory="templates")


# Base.metadata.create_all(bind=engine) ### Не работает так как нет бд здесь пока что


# ======= ОСНОВНАЯ СТРАНИЦЫ =======
@app.get("/", response_class=HTMLResponse)
async def main(reqeust: Request):
    pass


# ======= ЛИЧНЫЙ КАБИНЕТ =======
@app.get("/me", response_class=HTMLResponse)
async def personal_acc(reqeust: Request):
    pass


# ======= АВТОРИЗАЦИЯ =======
@app.get("/login", response_class=HTMLResponse)
async def login(reqeust: Request):
    pass


# ======= РЕГИСТРАЦИЯ =======
@app.get("/registration", response_class=HTMLResponse)
async def registration(reqeust: Request):
    pass


# ======= СОБЫТИЕ =======
@app.get("/event", response_class=HTMLResponse)
async def event(reqeust: Request, event_id: int = 0):
    pass


# ======= АДМИН =======
@app.get("/admin", response_class=HTMLResponse)
async def admin(reqeust: Request):
    pass
